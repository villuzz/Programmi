sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Z001.ZPS_PSID.controller.BaseView", {
		onInit: function () {

		}

	});
});